# Fastshot auth SDK 1.2

The broker and SDK must be deployed as a compatible pair. Version 1.2 binds every OAuth/email-verification ticket to the app's project ID, exact callback, random state and S256 PKCE verifier. The verifier stays in web session storage or native Expo SecureStore until exchange. Provider-side PKCE is a separate proof.

## Installation and upgrade

Generated apps consume the reviewed local `fastshot-auth-1.2.2.tgz` artifact bundled with the code service. This change does not publish a package to npm. Install `expo-crypto` and `expo-secure-store` with `npx expo install` so native package versions match the project's Expo SDK.

Set `EXPO_PUBLIC_PROJECT_ID` to the canonical project UUID. The native Expo config must include `fastshot-<project-uuid>` in `scheme`; rebuild the native binary after changing schemes or native modules. The callback is `fastshot-<project-uuid>://auth/callback`. The global `fastshot://` callback is no longer accepted.

Ship the code-service artifact/bootstrap and migrate existing workspaces to the current SDK. The broker always requires client proof and the project-specific native callback scheme. Old unbound clients receive HTTP 426 `sdk_upgrade_required` and must rebuild. There is no legacy-native compatibility flag. Existing authenticated Supabase sessions and password sign-in remain independent of ticket exchange.

## Web and preview behavior

Use `isInitializing` for root-screen and layout loading guards. It is true only while the provider restores its initial session (or starts observing a replacement Supabase client). `isLoading` retains its existing meaning: initialization or an in-progress sign-in/sign-out. Use it to disable submit buttons, keeping the form mounted so input and errors survive a failed request. `GuestLayout` and `ProtectedLayout` use initialization-only guards.

```tsx
function RootIndex() {
  const { isInitializing, isAuthenticated } = useAuth();
  if (isInitializing) return <ActivityIndicator />;
  return isAuthenticated ? <HomeScreen /> : <AuthScreen />;
}
```

Inside `AuthScreen`, disable its sign-in button with `isLoading` and display `useAuth().error?.message` or the error caught from `signInWithEmail`. Do not replace the whole screen while `isLoading`: that unmounts form state during the request.

The registered preview callback is exactly `https://<project-uuid>-port-8081.<GKE_INGRESS_DOMAIN>/auth/callback`. Development/preview ingress permits HTTP only on the configured development domain. Arbitrary callbacks, sibling projects, deleted projects, query/fragment additions and the old global native scheme are rejected.

Published gallery previews have app sign-in disabled. The gallery and publish dialog display this limitation. The SDK declines OAuth, email sign-in, sign-up and password reset before opening a popup or contacting Supabase, and does not restore a session in the gallery preview. The broker rejects published callbacks. Editor preview and native authentication retain their existing flows. Native sign-in still requires configured providers and a rebuilt app; publication does not verify it.

Inside a phone iframe, sign-in opens a popup synchronously from the click. The app stays mounted. Its callback page sends a receipt to the same-origin opener; the opener verifies the exact window, origin, URL and random state before exchanging the ticket. Popup blockers and lost/closed windows produce visible errors. Standalone web apps use same-tab navigation. If a provider uses a policy that severs the opener, the flow must be tested with that provider before declaring it ready; the SDK cannot infer success from a closed window.

Email verification submits session tokens to the broker in a POST body. The broker validates the access token against the managed tenant before minting a bound ticket. Native verification links can cold-start the original app. Web verification must return to the original browsing session that owns the verifier; another tab/device receives a clear restart-sign-in message and may still sign in with its confirmed email and password. Password-reset links use the broker form and a single-use state, then users sign in normally.

## Verification

From the platform root, run `node node_modules/vitest/vitest.mjs run --config packages/fastshot-auth/tests/vitest.config.ts`. From `auth-broker`, run its pytest suite with `--asyncio-mode=auto` and isolated Redis at `127.0.0.1:56379/5`.

`e2e/build.mjs` runs `npm pack`, extracts that exact artifact and bundles the packed SDK. `e2e/auth_fixture_server.py` runs real broker routes and Redis with synthetic tenant/provider boundaries. `e2e/auth_browser_e2e.py` records a cross-origin phone iframe completing sign-in and cancellation with the actual Supabase JS client. Run `uvicorn auth_fixture_server:app` from `auth-broker` with `PYTHONPATH=.` and `--app-dir ../packages/fastshot-auth/e2e` on port 8096, and use `AUTH_E2E_OUTPUT` consistently for all three commands. The browser runner uses a local transport for fixture hostnames and renders returned redirect Locations as fresh navigations because Playwright intercepts only the first request of a redirect chain.

This fixture proves the SDK/broker/Redis protocol and iframe lifecycle. It does not prove live Google/Apple configuration, delivered email, physical-device deep links or published auth on the shared CDN.
