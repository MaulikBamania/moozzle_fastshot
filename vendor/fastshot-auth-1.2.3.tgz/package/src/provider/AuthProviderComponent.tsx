import { isGalleryPreview, requireInteractiveAuth } from '../utils/galleryPreview';
/**
 * AuthProvider - Opinionated, robust authentication provider for React Native
 *
 * Provides automatic session management, OAuth sign-in methods, and reactive
 * auth state updates. Just wrap your app and use the useAuth() hook.
 *
 * ## Simplest Setup (Recommended)
 *
 * Just add the `routes` config - redirects are automatic!
 *
 * @example
 * ```tsx
 * // app/_layout.tsx - This is ALL you need for auth routing!
 * import { Stack } from 'expo-router';
 * import { AuthProvider } from '@fastshot/auth';
 * import { supabase } from '@/lib/supabase';
 *
 * export default function RootLayout() {
 *   return (
 *     <AuthProvider
 *       supabaseClient={supabase}
 *       routes={{
 *         login: '/(auth)/login',
 *         afterLogin: '/(tabs)',
 *       }}
 *     >
 *       <Stack screenOptions={{ headerShown: false }}>
 *         <Stack.Screen name="(auth)" />
 *         <Stack.Screen name="(tabs)" />
 *       </Stack>
 *     </AuthProvider>
 *   );
 * }
 *
 * // app/(auth)/login.tsx - Use auth in screens
 * import { useAuth } from '@fastshot/auth';
 *
 * export default function LoginScreen() {
 *   const { signInWithGoogle, isLoading } = useAuth();
 *   return <Button onPress={signInWithGoogle} disabled={isLoading}>Sign In</Button>;
 * }
 * ```
 *
 * That's it! The `routes` config automatically:
 * - Redirects unauthenticated users from (tabs) to login
 * - Redirects authenticated users from (auth) to tabs
 *
 * ## Alternative: Layout Wrappers
 *
 * For more control, use `ProtectedLayout` and `GuestLayout` instead of `routes`:
 *
 * ```tsx
 * // app/(tabs)/_layout.tsx
 * import { ProtectedLayout } from '@fastshot/auth';
 * export default function TabsLayout() {
 *   return <ProtectedLayout><Tabs>...</Tabs></ProtectedLayout>;
 * }
 *
 * // app/(auth)/_layout.tsx
 * import { GuestLayout } from '@fastshot/auth';
 * export default function AuthLayout() {
 *   return <GuestLayout><Stack>...</Stack></GuestLayout>;
 * }
 * ```
 */

import React, {
  useContext,
  useEffect,
  useState,
  useCallback,
  useMemo,
  useRef,
  ReactNode,
} from 'react';
import { Platform, AppState, AppStateStatus } from 'react-native';
import * as WebBrowser from 'expo-web-browser';
import * as Linking from 'expo-linking';
import { useSegments, useRouter, type Href } from 'expo-router';
import { AuthContext } from './auth-context';
import type { SupabaseClient, Session, User, AuthChangeEvent } from '@supabase/supabase-js';
import type { AuthError, SignUpResult, PasswordResetResult, AuthRoutes } from '../types';
import {
  getDefaultCallbackUrl,
  parseCallbackUrl,
  isAuthCallbackUrl,
  buildOAuthStartUrl,
  exchangeTicket,
  restoreSession,
  createAuthError,
} from '../utils';
import { getProjectId } from '../env';
import { AUTH_CONFIG } from '../constants';
import { prepareClientBinding, getClientBinding, clearClientBinding } from '../utils/clientBinding';
import { openAuthPopup } from '../utils/webPopup';

/**
 * Configuration for AuthProvider
 */
export interface AuthProviderConfig {
  /** Supabase client instance - required */
  supabaseClient: SupabaseClient;
  /** Children to render */
  children: ReactNode;
  /**
   * Route configuration for automatic auth-based redirects.
   * When provided, AuthProvider will automatically redirect users based on auth state.
   * This is the RECOMMENDED way to set up auth - no need for ProtectedLayout/GuestLayout.
   *
   * @example
   * ```tsx
   * <AuthProvider
   *   supabaseClient={supabase}
   *   routes={{
   *     login: '/(auth)/login',
   *     afterLogin: '/(tabs)',
   *   }}
   * >
   * ```
   */
  routes?: AuthRoutes;
  /**
   * Callback fired after successful sign-in
   * Use for side effects like loading user data, analytics, etc.
   */
  onSignIn?: (user: User) => void | Promise<void>;
  /**
   * Callback fired after sign-out
   * Use for cleanup, analytics, etc.
   */
  onSignOut?: () => void | Promise<void>;
  /**
   * Callback fired when auth error occurs
   * Errors are also available via useAuth().error
   */
  onError?: (error: AuthError) => void;
  /**
   * Callback fired when email confirmation is required after sign-up
   * Use to show "check your email" UI
   */
  onEmailConfirmationRequired?: (email: string) => void;
  /**
   * Callback fired when password reset email is sent
   * Use to show "check your email" UI
   */
  onPasswordResetEmailSent?: (email: string) => void;
  /**
   * Callback fired when email is verified
   * This happens after user clicks the email verification link
   */
  onEmailVerified?: (user: User) => void;
}

/**
 * Options for email sign-up
 */
export interface SignUpOptions {
  /** Additional user metadata to store */
  data?: Record<string, unknown>;
}

/**
 * Auth context value returned by useAuth()
 */
export interface AuthContextValue {
  /** Current session, null if not authenticated */
  session: Session | null;
  /** Current user, null if not authenticated */
  user: User | null;
  /** True while initializing or during sign-in/sign-out */
  isLoading: boolean;
  /** True only while restoring the initial session; use for screen/layout guards */
  isInitializing: boolean;
  /** True if user is authenticated */
  isAuthenticated: boolean;
  /** Current error, null if no error */
  error: AuthError | null;
  /** True if waiting for email verification after sign-up */
  pendingEmailVerification: boolean;
  /** True if waiting for password reset email click */
  pendingPasswordReset: boolean;
  /** Sign in with Google OAuth */
  signInWithGoogle: () => Promise<void>;
  /** Sign in with Apple OAuth (iOS only, no-op on other platforms) */
  signInWithApple: () => Promise<void>;
  /** Sign in with email and password */
  signInWithEmail: (email: string, password: string) => Promise<void>;
  /** Sign up with email and password - returns result with emailConfirmationRequired flag */
  signUpWithEmail: (email: string, password: string, options?: SignUpOptions) => Promise<SignUpResult>;
  /** Send password reset email - returns result with emailSent flag */
  resetPassword: (email: string) => Promise<PasswordResetResult>;
  /** Sign out and clear session */
  signOut: () => Promise<void>;
  /** Clear current error */
  clearError: () => void;
}

/**
 * Internal component that handles automatic redirects based on auth state.
 * This is rendered inside AuthProvider when `routes` config is provided.
 */
function AuthRedirectHandler({
  routes,
  children,
}: {
  routes: AuthRoutes;
  children: ReactNode;
}) {
  const auth = useContext(AuthContext);
  const segments = useSegments();
  const router = useRouter();

  useEffect(() => {
    if (!auth || auth.isInitializing) return;

    const currentSegment = segments[0] as string | undefined;
    if (!currentSegment) return;

    // Normalize segment (remove parentheses if present)
    const normalizeSegment = (s: string) => s.replace(/^\(|\)$/g, '');
    const normalizedCurrent = normalizeSegment(currentSegment);

    // Check if current route is in protected list
    const protectedRoutes = routes.protected ?? ['tabs', 'app', 'home', 'main', 'dashboard'];
    const isProtectedRoute = protectedRoutes.some(
      (r) => normalizeSegment(r) === normalizedCurrent
    );

    // Check if current route is in guest list
    const guestRoutes = routes.guest ?? ['auth', 'login', 'signin', 'signup', 'register'];
    const isGuestRoute = guestRoutes.some(
      (r) => normalizeSegment(r) === normalizedCurrent
    );

    // Redirect logic
    if (!auth.session && isProtectedRoute) {
      // Not authenticated but on protected route -> redirect to login
      router.replace(routes.login as Href);
    } else if (auth.session && isGuestRoute) {
      // Authenticated but on guest route -> redirect to app
      router.replace(routes.afterLogin as Href);
    }
  }, [auth, auth?.session, auth?.isInitializing, segments, router, routes]);

  return <>{children}</>;
}

/**
 * AuthProvider component
 *
 * Wrap your app with this provider to enable authentication.
 * Must be placed at the root of your app, above any navigation.
 */
export function AuthProvider({
  supabaseClient,
  children,
  routes,
  onSignIn,
  onSignOut,
  onError,
  onEmailConfirmationRequired,
  onPasswordResetEmailSent,
  onEmailVerified,
}: AuthProviderConfig) {
  const [session, setSession] = useState<Session | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isInitializing, setIsInitializing] = useState(true);
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [error, setError] = useState<AuthError | null>(null);
  const [pendingEmailVerification, setPendingEmailVerification] = useState(false);
  const [pendingPasswordReset, setPendingPasswordReset] = useState(false);

  // Track the current sign-in attempt to prevent race conditions
  // Each sign-in gets a unique ID, and callbacks check against it
  const signInAttemptRef = useRef<string | null>(null);

  // Track if a callback URL is currently being processed
  const processingCallbackRef = useRef(false);

  // Store callbacks in refs to avoid re-subscribing to auth state changes
  // when callbacks change (consumer may not memoize them)
  const onSignInRef = useRef(onSignIn);
  const onSignOutRef = useRef(onSignOut);
  const onEmailConfirmationRequiredRef = useRef(onEmailConfirmationRequired);
  const onPasswordResetEmailSentRef = useRef(onPasswordResetEmailSent);
  const onEmailVerifiedRef = useRef(onEmailVerified);

  // Keep refs in sync with props
  useEffect(() => {
    onSignInRef.current = onSignIn;
  }, [onSignIn]);

  useEffect(() => {
    onSignOutRef.current = onSignOut;
  }, [onSignOut]);

  useEffect(() => {
    onEmailConfirmationRequiredRef.current = onEmailConfirmationRequired;
  }, [onEmailConfirmationRequired]);

  useEffect(() => {
    onPasswordResetEmailSentRef.current = onPasswordResetEmailSent;
  }, [onPasswordResetEmailSent]);

  useEffect(() => {
    onEmailVerifiedRef.current = onEmailVerified;
  }, [onEmailVerified]);

  // Generate a unique ID for each sign-in attempt
  const generateAttemptId = useCallback(() => {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }, []);

  // Handle errors consistently
  const handleError = useCallback(
    (authError: AuthError) => {
      // Don't treat browser dismissal as an error
      if (authError.type === 'BROWSER_DISMISSED') {
        return;
      }
      setError(authError);
      onError?.(authError);
    },
    [onError]
  );

  // Clear error
  const clearError = useCallback(() => {
    setError(null);
  }, []);

  // Reset sign-in state helper
  const resetSignInState = useCallback(() => {
    setIsSigningIn(false);
    processingCallbackRef.current = false;
  }, []);

  // Handle OAuth callback URL
  const handleCallbackUrl = useCallback(
    async (url: string): Promise<boolean> => {
      if (!isAuthCallbackUrl(url)) {
        return false;
      }

      // Prevent concurrent callback processing
      if (processingCallbackRef.current) {
        return true;
      }
      processingCallbackRef.current = true;

      const { ticket, error: urlError, errorDescription, clientState } = parseCallbackUrl(url);

      try {
        await getClientBinding(clientState);
        if (urlError) {
          await clearClientBinding(clientState!);
          throw createAuthError('CALLBACK_ERROR', errorDescription || urlError);
        }
        if (!ticket) throw createAuthError('CALLBACK_ERROR', 'No ticket in callback URL');
        setIsSigningIn(true);
        const exchangeResponse = await exchangeTicket(ticket, clientState);
        await restoreSession(supabaseClient, exchangeResponse);
        return true;
      } catch (err) {
        handleError((err as AuthError).type ? err as AuthError : createAuthError('CALLBACK_ERROR', err instanceof Error ? err.message : 'Sign-in callback failed'));
        return true;
      } finally {
        resetSignInState();
      }
    },
    [supabaseClient, handleError, resetSignInState]
  );

  // Core sign-in function
  const signInWithProvider = useCallback(
    async (provider: 'google' | 'apple') => {
      // Apple Sign-In only on iOS - throw error so caller knows it failed
      if (provider === 'apple' && Platform.OS !== 'ios') {
        const authError = createAuthError(
          'UNKNOWN_ERROR',
          'Apple Sign-In is only available on iOS'
        );
        handleError(authError);
        throw authError;
      }

      // Prevent concurrent sign-in attempts
      if (isSigningIn) {
        console.warn('[@fastshot/auth] Sign-in already in progress');
        return;
      }

      setError(null);
      setIsSigningIn(true);

      // Generate new attempt ID and reset processing flag
      const attemptId = generateAttemptId();
      signInAttemptRef.current = attemptId;
      processingCallbackRef.current = false;

      // A phone preview is an iframe: keep it mounted while the provider opens above it.
      let popup: ReturnType<typeof openAuthPopup> | undefined;
      try {
        requireInteractiveAuth();
        if (Platform.OS === 'web' && typeof window !== 'undefined' && window.parent !== window) popup = openAuthPopup();
        const binding = await prepareClientBinding();
        const projectId = getProjectId();
        const returnTo = getDefaultCallbackUrl();

        const authUrl = buildOAuthStartUrl(provider, {
          tenant: projectId,
          returnTo,
          mode: popup ? 'popup' : 'browser',
          clientChallenge: binding.client_challenge,
          clientState: binding.client_state,
        });

        if (popup) {
          await handleCallbackUrl(await popup.navigate(authUrl, binding.client_state));
          return;
        }
        // Standalone web apps retain their verifier in session storage across navigation.
        if (Platform.OS === 'web' && typeof window !== 'undefined') {
          // Redirect to OAuth - the callback page will handle the rest
          window.location.href = authUrl;
          return;
        }

        // NATIVE: Use WebBrowser.openAuthSessionAsync
        // This opens an in-app browser and returns the callback URL directly
        const result = await WebBrowser.openAuthSessionAsync(authUrl, returnTo);

        // Check if this attempt is still current (not superseded)
        if (signInAttemptRef.current !== attemptId) {
          return;
        }

        if (result.type === 'cancel' || result.type === 'dismiss') {
          // User cancelled - not an error, just reset state
          resetSignInState();
          return;
        }

        if (result.type === 'success' && result.url) {
          // Handle the callback URL directly (native platforms)
          await handleCallbackUrl(result.url);
        } else {
          // Unexpected result type
          resetSignInState();
        }
      } catch (err) {
        popup?.close();
        // Check if this attempt is still current
        if (signInAttemptRef.current !== attemptId) {
          return;
        }

        const authError =
          (err as AuthError).type !== undefined
            ? (err as AuthError)
            : createAuthError(
                'UNKNOWN_ERROR',
                err instanceof Error ? err.message : 'Sign-in failed'
              );
        handleError(authError);
        resetSignInState();
      }
    },
    [handleCallbackUrl, handleError, resetSignInState, generateAttemptId, isSigningIn]
  );

  // Sign in with Google
  const signInWithGoogle = useCallback(() => signInWithProvider('google'), [signInWithProvider]);

  // Sign in with Apple
  const signInWithApple = useCallback(() => signInWithProvider('apple'), [signInWithProvider]);

  // Sign in with email and password
  const signInWithEmail = useCallback(
    async (email: string, password: string) => {
      // Prevent concurrent sign-in attempts
      if (isSigningIn) {
        console.warn('[@fastshot/auth] Sign-in already in progress');
        return;
      }

      setError(null);
      setIsSigningIn(true);

      try {
        requireInteractiveAuth();
        const { error: signInError } = await supabaseClient.auth.signInWithPassword({
          email: email.trim(),
          password,
        });

        if (signInError) {
          throw createAuthError('UNKNOWN_ERROR', signInError.message);
        }
        // Session will be set via onAuthStateChange
      } catch (err) {
        const authError =
          (err as AuthError).type !== undefined
            ? (err as AuthError)
            : createAuthError('UNKNOWN_ERROR', err instanceof Error ? err.message : 'Sign-in failed');
        handleError(authError);
        throw authError;
      } finally {
        setIsSigningIn(false);
      }
    },
    [supabaseClient, handleError, isSigningIn]
  );

  // Build email verification redirect URL via auth-broker
  const buildEmailVerifyRedirectUrl = useCallback(async () => {
    const projectId = getProjectId();
    const returnTo = getDefaultCallbackUrl();
    const authBrokerUrl = AUTH_CONFIG.AUTH_BROKER_URL;
    const binding = await prepareClientBinding();
    const url = new URL('/v1/email/verify/callback', authBrokerUrl);
    url.searchParams.set('client_challenge', binding.client_challenge);
    url.searchParams.set('client_state', binding.client_state);
    url.searchParams.set('tenant', projectId);
    url.searchParams.set('return_to', returnTo);
    return url.toString();
  }, []);

  // Build password reset redirect URL via auth-broker
  const buildPasswordResetRedirectUrl = useCallback(() => {
    const projectId = getProjectId();
    const returnTo = getDefaultCallbackUrl();
    const authBrokerUrl = AUTH_CONFIG.AUTH_BROKER_URL;
    const url = new URL('/v1/email/reset/callback', authBrokerUrl);
    url.searchParams.set('tenant', projectId);
    url.searchParams.set('return_to', returnTo);
    return url.toString();
  }, []);

  // Sign up with email and password
  const signUpWithEmail = useCallback(
    async (email: string, password: string, options?: SignUpOptions): Promise<SignUpResult> => {
      const trimmedEmail = email.trim();

      // Prevent concurrent sign-in attempts
      if (isSigningIn) {
        console.warn('[@fastshot/auth] Sign-up already in progress');
        return { emailConfirmationRequired: false, email: trimmedEmail };
      }

      setError(null);
      setIsSigningIn(true);
      setPendingEmailVerification(false);

      try {
        requireInteractiveAuth();
        const { data, error: signUpError } = await supabaseClient.auth.signUp({
          email: trimmedEmail,
          password,
          options: {
            data: options?.data,
            emailRedirectTo: await buildEmailVerifyRedirectUrl(),
          },
        });

        if (signUpError) {
          throw createAuthError('UNKNOWN_ERROR', signUpError.message);
        }

        // Check if email confirmation is required
        // Supabase returns user with identities: [] when email confirmation is pending
        const emailConfirmationRequired = data.user !== null &&
          data.session === null;

        if (emailConfirmationRequired) {
          setPendingEmailVerification(true);
          // Fire callback
          queueMicrotask(() => {
            onEmailConfirmationRequiredRef.current?.(trimmedEmail);
          });
        }

        return {
          emailConfirmationRequired,
          email: trimmedEmail,
        };
      } catch (err) {
        const authError =
          (err as AuthError).type !== undefined
            ? (err as AuthError)
            : createAuthError('UNKNOWN_ERROR', err instanceof Error ? err.message : 'Sign-up failed');
        handleError(authError);
        throw authError;
      } finally {
        setIsSigningIn(false);
      }
    },
    [supabaseClient, handleError, isSigningIn, buildEmailVerifyRedirectUrl]
  );

  // Reset password
  const resetPassword = useCallback(
    async (email: string): Promise<PasswordResetResult> => {
      const trimmedEmail = email.trim();
      setError(null);
      setPendingPasswordReset(false);

      try {
        requireInteractiveAuth();
        const { error: resetError } = await supabaseClient.auth.resetPasswordForEmail(
          trimmedEmail,
          {
            redirectTo: buildPasswordResetRedirectUrl(),
          }
        );

        if (resetError) {
          throw createAuthError('UNKNOWN_ERROR', resetError.message);
        }

        // Set pending state and fire callback
        setPendingPasswordReset(true);
        queueMicrotask(() => {
          onPasswordResetEmailSentRef.current?.(trimmedEmail);
        });

        return {
          emailSent: true,
          email: trimmedEmail,
        };
      } catch (err) {
        const authError =
          (err as AuthError).type !== undefined
            ? (err as AuthError)
            : createAuthError('UNKNOWN_ERROR', err instanceof Error ? err.message : 'Password reset failed');
        handleError(authError);
        throw authError;
      }
    },
    [supabaseClient, handleError, buildPasswordResetRedirectUrl]
  );

  // Sign out
  const signOut = useCallback(async () => {
    setError(null);
    setIsLoading(true);

    // Reset sign-in tracking state
    signInAttemptRef.current = null;
    processingCallbackRef.current = false;

    try {
      const { error: signOutError } = await supabaseClient.auth.signOut();
      if (signOutError) {
        throw createAuthError('UNKNOWN_ERROR', signOutError.message);
      }
      // Session will be cleared via onAuthStateChange
    } catch (err) {
      const authError =
        (err as AuthError).type !== undefined
          ? (err as AuthError)
          : createAuthError('UNKNOWN_ERROR', err instanceof Error ? err.message : 'Sign-out failed');
      handleError(authError);
      setIsLoading(false);
    }
  }, [supabaseClient, handleError]);

  // NOTE: Web callback handling is done by AuthCallbackPage component
  // AuthProvider should NOT process callbacks on web to avoid double-exchange
  // This useEffect is intentionally removed for web platform

  // Initialize: listen for auth state changes (including INITIAL_SESSION)
  useEffect(() => {
    let mounted = true;
    setIsInitializing(true);

    if (isGalleryPreview()) {
      setSession(null);
      setIsInitializing(false);
      setIsLoading(false);
      return;
    }

    // Listen for auth state changes
    // INITIAL_SESSION fires immediately with the current session state
    const {
      data: { subscription },
    } = supabaseClient.auth.onAuthStateChange(
      async (event: AuthChangeEvent, newSession: Session | null) => {
        if (!mounted) return;

        setSession(newSession);
        setIsInitializing(false);

        // Handle INITIAL_SESSION - this is the initial load, not a sign-in action
        if (event === 'INITIAL_SESSION') {
          setIsLoading(false);
          return;
        }

        setIsSigningIn(false);
        setIsLoading(false);

        // Fire callbacks in next microtask to avoid Supabase internal lock deadlock
        // (callbacks may call Supabase methods which would deadlock if called inside onAuthStateChange)
        if (event === 'SIGNED_IN' && newSession?.user) {
          const user = newSession.user;
          queueMicrotask(async () => {
            try {
              await onSignInRef.current?.(user);
            } catch (err) {
              console.error('[@fastshot/auth] onSignIn callback error:', err);
            }
          });
        } else if (event === 'SIGNED_OUT') {
          queueMicrotask(async () => {
            try {
              await onSignOutRef.current?.();
            } catch (err) {
              console.error('[@fastshot/auth] onSignOut callback error:', err);
            }
          });
        }
      }
    );

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, [supabaseClient]); // Only re-subscribe when supabaseClient changes

  // Handle app state changes for token refresh (native only)
  useEffect(() => {
    if (Platform.OS === 'web') return;

    const handleAppStateChange = (state: AppStateStatus) => {
      if (state === 'active') {
        supabaseClient.auth.startAutoRefresh();
      } else {
        supabaseClient.auth.stopAutoRefresh();
      }
    };

    const subscription = AppState.addEventListener('change', handleAppStateChange);

    return () => {
      subscription.remove();
    };
  }, [supabaseClient]);

  // Listen for deep links (native platforms)
  useEffect(() => {
    if (Platform.OS === 'web') return;

    // Check initial URL (app opened via deep link)
    const checkInitialUrl = async () => {
      const initialUrl = await Linking.getInitialURL();
      if (initialUrl) {
        await handleCallbackUrl(initialUrl);
      }
    };

    checkInitialUrl();

    // Listen for incoming URLs while app is running
    const subscription = Linking.addEventListener('url', ({ url }) => {
      handleCallbackUrl(url);
    });

    return () => {
      subscription.remove();
    };
  }, [handleCallbackUrl]);

  // Memoize context value to prevent unnecessary re-renders
  const value = useMemo<AuthContextValue>(
    () => ({
      session,
      user: session?.user ?? null,
      isLoading: isInitializing || isLoading || isSigningIn,
      isInitializing,
      isAuthenticated: !!session,
      error,
      pendingEmailVerification,
      pendingPasswordReset,
      signInWithGoogle,
      signInWithApple,
      signInWithEmail,
      signUpWithEmail,
      resetPassword,
      signOut,
      clearError,
    }),
    [session, isLoading, isInitializing, isSigningIn, error, pendingEmailVerification, pendingPasswordReset, signInWithGoogle, signInWithApple, signInWithEmail, signUpWithEmail, resetPassword, signOut, clearError]
  );

  return (
    <AuthContext.Provider value={value}>
      {routes ? (
        <AuthRedirectHandler routes={routes}>{children}</AuthRedirectHandler>
      ) : (
        children
      )}
    </AuthContext.Provider>
  );
}
