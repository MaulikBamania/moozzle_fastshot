/**
 * AuthCallbackPage - Web OAuth callback handler
 *
 * @example
 * ```tsx
 * // app/auth/callback.tsx
 * import { AuthCallbackPage } from '@fastshot/auth';
 * import { supabase } from '@/lib/supabase';
 * import { useRouter } from 'expo-router';
 *
 * export default function Callback() {
 *   const router = useRouter();
 *   return (
 *     <AuthCallbackPage
 *       supabaseClient={supabase}
 *       onSuccess={() => router.replace('/')}
 *     />
 *   );
 * }
 * ```
 */

import React, { useEffect, useRef, useState } from 'react';
import { View, Text, ActivityIndicator, StyleSheet, Platform, Pressable } from 'react-native';
import type { SupabaseClient } from '@supabase/supabase-js';
import { relayPopupCallback } from '../utils/webPopup';
import { parseCallbackUrl, exchangeTicket, restoreSession, isAuthError } from '../utils';

interface AuthCallbackPageProps {
  supabaseClient: SupabaseClient;
  onSuccess?: () => void;
  onError?: (error: Error) => void;
  loadingText?: string;
}

type Status = 'loading' | 'success' | 'error';

// Share an in-flight exchange across remounts without retaining consumed tickets.
const pendingCallbacks = new WeakMap<SupabaseClient, Map<string, Promise<void>>>();

function completeCallback(supabaseClient: SupabaseClient, ticket: string, clientState?: string): Promise<void> {
  let pending = pendingCallbacks.get(supabaseClient);
  if (!pending) {
    pending = new Map();
    pendingCallbacks.set(supabaseClient, pending);
  }
  const existing = pending.get(ticket);
  if (existing) return existing;

  const completion = (async () => {
    const tokens = await exchangeTicket(ticket, clientState);
    await restoreSession(supabaseClient, tokens);
  })();
  pending.set(ticket, completion);
  const clearPending = () => { pending.delete(ticket); };
  void completion.then(clearPending, clearPending);
  return completion;
}

export function AuthCallbackPage({
  supabaseClient,
  onSuccess,
  onError,
  loadingText = 'Completing sign in...',
}: AuthCallbackPageProps) {
  const [status, setStatus] = useState<Status>('loading');
  const [error, setError] = useState<string | null>(null);

  const callbacks = useRef({ onSuccess, onError });
  const operation = useRef<{
    client: SupabaseClient;
    ticket: string;
    completion: Promise<void>;
  } | null>(null);

  useEffect(() => {
    callbacks.current = { onSuccess, onError };
  }, [onSuccess, onError]);

  useEffect(() => {
    if (Platform.OS !== 'web' || typeof window === 'undefined') return;

    if (relayPopupCallback()) return;

    const { ticket, error: urlError, errorDescription, clientState } = parseCallbackUrl(window.location.href);
    if (urlError || !ticket) {
      const message = urlError ? errorDescription || urlError : 'No ticket found in URL';
      setError(message);
      setStatus('error');
      callbacks.current.onError?.(new Error(urlError ? message : 'No ticket found'));
      return;
    }

    let active = true;
    let navigationTimer: ReturnType<typeof setTimeout> | undefined;
    setStatus('loading');
    setError(null);

    // Keep the result through effect replay, even if the one-time exchange has settled.
    if (operation.current?.client !== supabaseClient || operation.current.ticket !== ticket) {
      operation.current = { client: supabaseClient, ticket, completion: completeCallback(supabaseClient, ticket, clientState) };
    }

    void operation.current.completion.then(() => {
      if (!active) return;
      setStatus('success');
      navigationTimer = setTimeout(() => {
        if (callbacks.current.onSuccess) {
          callbacks.current.onSuccess();
        } else {
          window.location.replace('/');
        }
      }, 50);
    }, (err: unknown) => {
      if (!active) return;
      const message = isAuthError(err) ? err.message : err instanceof Error ? err.message : 'Failed';
      console.error('[@fastshot/auth] Callback failed:', err);
      setError(message);
      setStatus('error');
      callbacks.current.onError?.(new Error(message));
    });

    return () => {
      active = false;
      clearTimeout(navigationTimer);
    };
  }, [supabaseClient]);

  const navigate = () => {
    if (callbacks.current.onSuccess) {
      callbacks.current.onSuccess();
    } else {
      window.location.replace('/');
    }
  };

  return (
    <View style={styles.container}>
      {status === 'loading' && (
        <>
          <ActivityIndicator size="large" color="#4A7C59" />
          <Text style={styles.text}>{loadingText}</Text>
        </>
      )}
      {status === 'success' && (
        <>
          <Text style={styles.success}>Sign in successful!</Text>
          <Pressable onPress={navigate} style={styles.button}>
            <Text style={styles.buttonText}>Continue →</Text>
          </Pressable>
        </>
      )}
      {status === 'error' && (
        <>
          <Text style={styles.error}>{error}</Text>
          <Pressable onPress={() => window.history.back()} style={styles.link}>
            <Text style={styles.linkText}>← Go back</Text>
          </Pressable>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', padding: 20 },
  text: { marginTop: 16, fontSize: 16, color: '#666' },
  success: { fontSize: 20, fontWeight: '600', color: '#16a34a', marginBottom: 16 },
  error: { fontSize: 16, color: '#dc2626', textAlign: 'center', marginBottom: 16 },
  button: { paddingHorizontal: 24, paddingVertical: 12, backgroundColor: '#4A7C59', borderRadius: 8 },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: '600' },
  link: { padding: 12 },
  linkText: { color: '#4A7C59', fontSize: 16 },
});
