/**
 * Layout wrappers for automatic auth-based redirects
 *
 * These components simplify protecting routes in expo-router apps.
 * Use ProtectedLayout for authenticated-only routes and GuestLayout for
 * unauthenticated-only routes (like login screens).
 *
 * @example
 * ```tsx
 * // app/(tabs)/_layout.tsx - Protected route
 * import { ProtectedLayout } from '@fastshot/auth';
 *
 * export default function TabsLayout() {
 *   return (
 *     <ProtectedLayout>
 *       <Tabs>...</Tabs>
 *     </ProtectedLayout>
 *   );
 * }
 *
 * // app/(auth)/_layout.tsx - Guest-only route
 * import { GuestLayout } from '@fastshot/auth';
 *
 * export default function AuthLayout() {
 *   return (
 *     <GuestLayout>
 *       <Stack>...</Stack>
 *     </GuestLayout>
 *   );
 * }
 * ```
 */

import React, { ReactNode } from 'react';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import { Redirect, type Href } from 'expo-router';
import { useAuth } from './AuthProvider';

/**
 * Props for ProtectedLayout
 */
export interface ProtectedLayoutProps {
  /** Children to render when authenticated */
  children: ReactNode;
  /**
   * Route to redirect to when not authenticated
   * @default '/(auth)/login'
   */
  redirectTo?: string;
  /**
   * Custom loading component to show while checking auth
   * @default ActivityIndicator
   */
  loadingComponent?: ReactNode;
}

/**
 * Props for GuestLayout
 */
export interface GuestLayoutProps {
  /** Children to render when not authenticated */
  children: ReactNode;
  /**
   * Route to redirect to when authenticated
   * @default '/(tabs)'
   */
  redirectTo?: string;
  /**
   * Custom loading component to show while checking auth
   * @default ActivityIndicator
   */
  loadingComponent?: ReactNode;
}

const DefaultLoadingComponent = () => (
  <View style={styles.loading}>
    <ActivityIndicator size="large" color="#4A7C59" />
  </View>
);

/**
 * ProtectedLayout - Wrapper for routes that require authentication
 *
 * Automatically redirects unauthenticated users to the login route.
 * Shows a loading indicator while checking authentication status.
 *
 * @example
 * ```tsx
 * // app/(tabs)/_layout.tsx
 * import { ProtectedLayout } from '@fastshot/auth';
 * import { Tabs } from 'expo-router';
 *
 * export default function TabsLayout() {
 *   return (
 *     <ProtectedLayout>
 *       <Tabs>
 *         <Tabs.Screen name="index" options={{ title: 'Home' }} />
 *         <Tabs.Screen name="profile" options={{ title: 'Profile' }} />
 *       </Tabs>
 *     </ProtectedLayout>
 *   );
 * }
 *
 * // With custom redirect
 * <ProtectedLayout redirectTo="/sign-in">
 *   <Tabs>...</Tabs>
 * </ProtectedLayout>
 * ```
 */
export function ProtectedLayout({
  children,
  redirectTo = '/(auth)/login',
  loadingComponent,
}: ProtectedLayoutProps) {
  const { session, isInitializing } = useAuth();

  if (isInitializing) {
    return loadingComponent ?? <DefaultLoadingComponent />;
  }

  if (!session) {
    return <Redirect href={redirectTo as Href} />;
  }

  return <>{children}</>;
}

/**
 * GuestLayout - Wrapper for routes that should only be accessible to unauthenticated users
 *
 * Automatically redirects authenticated users to the main app route.
 * Useful for login, signup, and other auth-related screens.
 *
 * @example
 * ```tsx
 * // app/(auth)/_layout.tsx
 * import { GuestLayout } from '@fastshot/auth';
 * import { Stack } from 'expo-router';
 *
 * export default function AuthLayout() {
 *   return (
 *     <GuestLayout>
 *       <Stack screenOptions={{ headerShown: false }}>
 *         <Stack.Screen name="login" />
 *         <Stack.Screen name="signup" />
 *       </Stack>
 *     </GuestLayout>
 *   );
 * }
 *
 * // With custom redirect
 * <GuestLayout redirectTo="/(app)/home">
 *   <Stack>...</Stack>
 * </GuestLayout>
 * ```
 */
export function GuestLayout({
  children,
  redirectTo = '/(tabs)',
  loadingComponent,
}: GuestLayoutProps) {
  const { session, isInitializing } = useAuth();

  if (isInitializing) {
    return loadingComponent ?? <DefaultLoadingComponent />;
  }

  if (session) {
    return <Redirect href={redirectTo as Href} />;
  }

  return <>{children}</>;
}

const styles = StyleSheet.create({
  loading: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
});
