import { createContext, useContext } from 'react';
import type { AuthContextValue } from './AuthProviderComponent';

export const AuthContext = createContext<AuthContextValue | null>(null);

/**
 * Hook to access auth state and methods
 *
 * Must be used within an AuthProvider.
 *
 * @example
 * ```tsx
 * function MyComponent() {
 *   const { user, isInitializing, isLoading, signInWithGoogle } = useAuth();
 *
 *   if (isInitializing) return <Loading />;
 *   if (!user) return <Button disabled={isLoading} onPress={signInWithGoogle}>Sign In</Button>;
 *   return <Text>Welcome, {user.email}</Text>;
 * }
 * ```
 */
export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error(
      '[@fastshot/auth] useAuth must be used within an AuthProvider.\n\n' +
        'Wrap your app with <AuthProvider supabaseClient={supabase}>:\n\n' +
        'import { AuthProvider } from "@fastshot/auth";\n' +
        'import { supabase } from "./lib/supabase";\n\n' +
        'export default function App() {\n' +
        '  return (\n' +
        '    <AuthProvider supabaseClient={supabase}>\n' +
        '      <YourApp />\n' +
        '    </AuthProvider>\n' +
        '  );\n' +
        '}'
    );
  }

  return context;
}
