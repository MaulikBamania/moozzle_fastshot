import { ENV } from './env';

/**
 * Auth Broker configuration
 *
 * Environment values are resolved from process.env.EXPO_PUBLIC_*
 * which are inlined by babel at build time.
 */
export const AUTH_CONFIG = {
  /** Auth broker URL */
  get AUTH_BROKER_URL(): string {
    return ENV.AUTH_BROKER_URL;
  },
  /** Project ID for authentication */
  get PROJECT_ID(): string {
    return ENV.PROJECT_ID;
  },
  /** Deep link scheme for OAuth callback */
  get DEEP_LINK_SCHEME(): string {
    const projectId = ENV.PROJECT_ID.toLowerCase();
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(projectId)) {
      throw new Error('A valid EXPO_PUBLIC_PROJECT_ID is required for app authentication.');
    }
    return `fastshot-${projectId}`;
  },
  /** Callback path for OAuth */
  CALLBACK_PATH: 'auth/callback',
} as const;

/**
 * OAuth endpoints on the auth broker
 */
export const AUTH_ENDPOINTS = {
  GOOGLE_START: '/v1/auth/google/start',
  APPLE_START: '/v1/auth/apple/start',
  EXCHANGE_TICKET: '/v1/auth/exchange',
} as const;

/**
 * Supported OAuth providers
 */
export type OAuthProvider = 'google' | 'apple';

/**
 * Default configuration values
 */
export const DEFAULT_AUTH_CONFIG = {
  TIMEOUT: 30000, // 30 seconds
  MODE: 'browser' as const,
} as const;
