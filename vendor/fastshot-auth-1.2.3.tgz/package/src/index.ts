/**
 * @fastshot/auth - Opinionated OAuth authentication for React Native Expo
 *
 * Provides Google and Apple OAuth authentication via Fastshot's auth-broker,
 * with automatic Supabase session management. Designed for Expo Router.
 *
 * ## Quick Start (2 Steps!)
 *
 * ### Step 1: Wrap your app with AuthProvider + routes config
 * ```tsx
 * // app/_layout.tsx - This is ALL you need for auth routing!
 * import { Stack } from 'expo-router';
 * import { AuthProvider } from '@fastshot/auth';
 * import { supabase } from '@/lib/supabase';
 *
 * export default function RootLayout() {
 *   return (
 *     <AuthProvider
 *       supabaseClient={supabase}
 *       routes={{
 *         login: '/(auth)/login',
 *         afterLogin: '/(tabs)',
 *       }}
 *     >
 *       <Stack screenOptions={{ headerShown: false }}>
 *         <Stack.Screen name="(auth)" />
 *         <Stack.Screen name="(tabs)" />
 *       </Stack>
 *     </AuthProvider>
 *   );
 * }
 * ```
 *
 * ### Step 2: Use auth in your screens
 * ```tsx
 * // app/(auth)/login.tsx
 * import { useAuth } from '@fastshot/auth';
 *
 * export default function LoginScreen() {
 *   const { signInWithGoogle, isLoading } = useAuth();
 *   return <Button onPress={signInWithGoogle} disabled={isLoading}>Sign In</Button>;
 * }
 * ```
 *
 * That's it! Auth redirects are automatic:
 * - Unauthenticated users visiting `(tabs)` → redirected to login
 * - Authenticated users visiting `(auth)` → redirected to tabs
 *
 * ## Features
 *
 * - **Minimal setup**: Just add `routes` config, redirects are automatic
 * - **Convention-based**: Common route names auto-detected (tabs, app, auth, etc.)
 * - **Expo Router native**: Designed for file-based routing with route groups
 * - **Reactive state**: UI automatically updates when auth state changes
 * - **Deep link handling**: Handles OAuth callbacks automatically
 * - **TypeScript**: Full type safety out of the box
 */

// =============================================================================
// PRIMARY API
// =============================================================================

/**
 * Primary exports - these are what most users need
 *
 * - AuthProvider: Wrap your app to enable auth
 * - useAuth: Hook to access auth state and methods
 * - ProtectedLayout: Wrapper for routes requiring authentication
 * - GuestLayout: Wrapper for routes that should only be accessible when logged out
 * - AuthCallbackPage: Web callback page component (only needed for web)
 */
export { AuthProvider, useAuth, AuthCallbackPage, ProtectedLayout, GuestLayout } from './provider';
export type { AuthProviderConfig, AuthContextValue, SignUpOptions, ProtectedLayoutProps, GuestLayoutProps } from './provider';

// =============================================================================
// TYPES
// =============================================================================

export type {
  AuthError,
  AuthErrorType,
  OAuthProvider,
  AuthMode,
  SignUpResult,
  PasswordResetResult,
  AuthRoutes,
} from './types';
