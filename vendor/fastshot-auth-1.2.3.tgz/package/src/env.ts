/**
 * Environment configuration for @fastshot/auth
 *
 * Uses direct process.env access which is inlined by babel at build time.
 * The babel.config.js in the template includes an override for @fastshot/*
 * packages that uses transform-inline-environment-variables plugin.
 *
 * If env vars are not properly inlined, these functions will throw errors
 * to help developers identify configuration issues.
 */

/**
 * Check if a value looks like an uninlined env var reference
 * This happens when babel doesn't inline the value
 */
function isUninlined(value: string | undefined): value is undefined | '' {
  return !value || value === 'undefined' || value.startsWith('process.env.');
}

/**
 * Get the Fastshot Project ID
 * @throws Error if EXPO_PUBLIC_PROJECT_ID is not configured
 */
export function getProjectId(): string {
  const value = process.env.EXPO_PUBLIC_PROJECT_ID;

  if (isUninlined(value)) {
    throw new Error(
      '[@fastshot/auth] EXPO_PUBLIC_PROJECT_ID is not configured.\n\n' +
      'Make sure:\n' +
      '1. EXPO_PUBLIC_PROJECT_ID is set in your .env file\n' +
      '2. babel.config.js has the @fastshot/* override with transform-inline-environment-variables\n' +
      '3. You\'ve cleared Metro cache after changing .env (npx expo start --clear)\n'
    );
  }

  return value as string;
}

/**
 * Get the Auth Broker URL
 * warns if EXPO_PUBLIC_AUTH_BROKER_URL is not configured
 */
export function getAuthBrokerUrl(): string {
  const value = process.env.EXPO_PUBLIC_AUTH_BROKER_URL;

  if (isUninlined(value)) {
    console.warn(
      '[@fastshot/auth] EXPO_PUBLIC_AUTH_BROKER_URL is not configured.\n\n' +
      'Make sure:\n' +
      '1. EXPO_PUBLIC_AUTH_BROKER_URL is set in your .env file\n' +
      '2. babel.config.js has the @fastshot/* override with transform-inline-environment-variables\n' +
      '3. You\'ve cleared Metro cache after changing .env (npx expo start --clear)\n'
    );
    return 'https://oauth.fastshot.ai';
  }

  return value as string;
}

/**
 * Environment configuration object with lazy evaluation
 * Values are resolved on first access and will throw if not configured
 */
export const ENV = {
  get PROJECT_ID(): string {
    return getProjectId();
  },
  get AUTH_BROKER_URL(): string {
    return getAuthBrokerUrl();
  },
} as const;
