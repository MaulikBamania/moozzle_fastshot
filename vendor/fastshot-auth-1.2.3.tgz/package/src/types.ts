import type { SupabaseClient, User, Session } from '@supabase/supabase-js';

/**
 * OAuth provider type
 */
export type OAuthProvider = 'google' | 'apple';

/**
 * Authentication mode
 * - browser: Opens system browser (recommended for most cases)
 * - webview: Opens in-app WebView (may have limitations)
 */
export type AuthMode = 'browser' | 'webview';

/**
 * Configuration for OAuth sign-in
 */
export interface SignInConfig {
  /** Supabase client instance for session restoration */
  supabaseClient: SupabaseClient;
  /** Custom return URL (defaults to fastshot://auth/callback) */
  returnTo?: string;
  /** Auth mode: 'browser' (default) or 'webview' */
  mode?: AuthMode;
  /** Email hint for Google sign-in */
  loginHint?: string;
}

/**
 * Response from ticket exchange
 */
export interface ExchangeTicketResponse {
  access_token: string;
  refresh_token: string;
  token_type: string;
  expires_in: number;
  user: User;
}

/**
 * Result from OAuth callback handling
 */
export interface AuthCallbackResult {
  success: boolean;
  session?: Session;
  user?: User;
  error?: string;
}

/**
 * Error types for authentication
 */
export type AuthErrorType =
  | 'INVALID_TICKET'
  | 'EXCHANGE_FAILED'
  | 'SESSION_RESTORE_FAILED'
  | 'CALLBACK_ERROR'
  | 'BROWSER_DISMISSED'
  | 'NETWORK_ERROR'
  | 'UNKNOWN_ERROR';

/**
 * Authentication error with type
 */
export interface AuthError {
  type: AuthErrorType;
  message: string;
  originalError?: unknown;
}

/**
 * State for auth hooks
 */
export interface AuthHookState {
  isLoading: boolean;
  error: AuthError | null;
}

/**
 * Result from useGoogleSignIn or useAppleSignIn hooks
 */
export interface UseSignInResult extends AuthHookState {
  signIn: () => Promise<void>;
  reset: () => void;
}

/**
 * Configuration for useAuthCallback hook
 */
export interface UseAuthCallbackConfig {
  /** Supabase client instance */
  supabaseClient: SupabaseClient;
  /** Callback when authentication succeeds */
  onSuccess?: (result: { session: Session; user: User }) => void;
  /** Callback when authentication fails */
  onError?: (error: AuthError) => void;
}

/**
 * Result from useAuthCallback hook
 */
export interface UseAuthCallbackResult {
  /** Whether callback is being processed */
  isProcessing: boolean;
  /** Error if callback processing failed */
  error: AuthError | null;
  /** Manually handle a callback URL */
  handleUrl: (url: string) => Promise<AuthCallbackResult>;
}

/**
 * Result from email sign-up
 */
export interface SignUpResult {
  /** Whether email confirmation is required */
  emailConfirmationRequired: boolean;
  /** The email address that was signed up */
  email: string;
}

/**
 * Result from password reset request
 */
export interface PasswordResetResult {
  /** Whether the reset email was sent successfully */
  emailSent: boolean;
  /** The email address the reset was sent to */
  email: string;
}

/**
 * Route configuration for automatic auth redirects
 *
 * @example
 * ```tsx
 * <AuthProvider
 *   supabaseClient={supabase}
 *   routes={{
 *     login: '/(auth)/login',
 *     afterLogin: '/(tabs)',
 *     protected: ['(tabs)', '(app)'],
 *     guest: ['(auth)'],
 *   }}
 * >
 * ```
 */
export interface AuthRoutes {
  /** Route to redirect unauthenticated users (e.g., '/(auth)/login') */
  login: string;
  /** Route to redirect after successful login (e.g., '/(tabs)') */
  afterLogin: string;
  /**
   * Route groups that require authentication.
   * Users without a session visiting these routes will be redirected to login.
   * Use route group names without parentheses prefix, e.g., ['tabs', 'app'] or ['(tabs)', '(app)']
   */
  protected?: string[];
  /**
   * Route groups for guests only (unauthenticated users).
   * Users with a session visiting these routes will be redirected to afterLogin.
   * Use route group names, e.g., ['auth'] or ['(auth)']
   */
  guest?: string[];
}
