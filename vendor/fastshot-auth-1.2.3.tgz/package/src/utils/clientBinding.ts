import { requireInteractiveAuth } from './galleryPreview';
import { Platform } from 'react-native';
import * as Crypto from 'expo-crypto';
import * as SecureStore from 'expo-secure-store';
import { getProjectId } from '../env';
import { getDefaultCallbackUrl } from './deepLink';

export interface ClientBinding {
  tenant: string;
  return_to: string;
  client_state: string;
  code_verifier: string;
  client_challenge: string;
  expires_at: number;
}

const lifetime = 24 * 60 * 60 * 1000; // Email verification may outlive a browser session.
const key = (state: string) => `fastshot.auth.${getProjectId()}.${state}`;
const base64url = (value: string) => value.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const hex = (bytes: Uint8Array) => Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('');

async function write(state: string, value: string): Promise<void> {
  if (Platform.OS === 'web') {
    window.sessionStorage.setItem(key(state), value);
  } else {
    await SecureStore.setItemAsync(key(state), value);
  }
}

/** The verifier never leaves this app until the ticket exchange. */
export async function prepareClientBinding(): Promise<ClientBinding> {
  requireInteractiveAuth();
  const native = Platform.OS !== 'web';
  const bytes = native ? await Crypto.getRandomBytesAsync(32) : crypto.getRandomValues(new Uint8Array(32));
  const codeVerifier = hex(bytes);
  const stateBytes = native ? await Crypto.getRandomBytesAsync(32) : crypto.getRandomValues(new Uint8Array(32));
  const challenge = native
    ? base64url(await Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, codeVerifier, { encoding: Crypto.CryptoEncoding.BASE64 }))
    : base64url(btoa(String.fromCharCode(...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(codeVerifier))))));
  const binding: ClientBinding = {
    tenant: getProjectId(), return_to: getDefaultCallbackUrl(), client_state: hex(stateBytes),
    code_verifier: codeVerifier, client_challenge: challenge, expires_at: Date.now() + lifetime,
  };
  // Fail closed when durable storage is unavailable; native callbacks may cold-start the app.
  await write(binding.client_state, JSON.stringify(binding));
  return binding;
}

export async function getClientBinding(state: string | undefined): Promise<ClientBinding> {
  requireInteractiveAuth();
  if (!state || !/^[A-Za-z0-9_-]{32,128}$/.test(state)) throw new Error('Sign-in does not match an app request. Please start sign-in again.');
  const value = Platform.OS === 'web' ? window.sessionStorage.getItem(key(state)) : await SecureStore.getItemAsync(key(state));
  const binding = value ? JSON.parse(value) as ClientBinding : null;
  if (!binding || binding.client_state !== state || binding.tenant !== getProjectId() ||
      binding.return_to !== getDefaultCallbackUrl() || binding.expires_at < Date.now()) {
    throw new Error('Sign-in expired or was started in another app or browser. Please start sign-in again.');
  }
  return binding;
}

export async function clearClientBinding(state: string): Promise<void> {
  if (Platform.OS === 'web') window.sessionStorage.removeItem(key(state));
  else await SecureStore.deleteItemAsync(key(state));
}
