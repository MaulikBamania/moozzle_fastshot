import { isAuthCallbackUrl, parseCallbackUrl } from './deepLink';

export const AUTH_POPUP_MESSAGE = 'fastshot:auth:callback';

/** Open synchronously in the click handler, before PKCE's asynchronous crypto work. */
export function openAuthPopup(): { navigate: (url: string, state: string) => Promise<string>; close: () => void } {
  const popup = window.open('about:blank', '_blank', 'popup,width=500,height=700');
  if (!popup) throw new Error('Allow popups for this app to sign in.');
  return {
    close: () => popup.close(),
    navigate: (url, state) => new Promise((resolve, reject) => {
      const finish = (callback?: string, error?: Error) => {
        window.removeEventListener('message', receive);
        clearInterval(poll);
        clearTimeout(timeout);
        popup.close();
        if (error) reject(error);
        else resolve(callback!);
      };
      const receive = (event: MessageEvent) => {
        if (event.source !== popup || event.origin !== window.location.origin ||
            event.data?.type !== AUTH_POPUP_MESSAGE || typeof event.data.url !== 'string' ||
            !isAuthCallbackUrl(event.data.url) || parseCallbackUrl(event.data.url).clientState !== state) return;
        finish(event.data.url);
      };
      window.addEventListener('message', receive);
      const poll = setInterval(() => { if (popup.closed) finish(undefined, new Error('Sign-in window was closed.')); }, 500);
      const timeout = setTimeout(() => finish(undefined, new Error('Sign-in timed out. Please try again.')), 5 * 60 * 1000);
      popup.location.replace(url);
    }),
  };
}

/** Return a receipt to the exact same-origin opener; the opener retains the verifier. */
export function relayPopupCallback(): boolean {
  if (!window.opener || !isAuthCallbackUrl(window.location.href) ||
      new URL(window.location.href).searchParams.get('popup') !== '1') return false;
  window.opener.postMessage({ type: AUTH_POPUP_MESSAGE, url: window.location.href }, window.location.origin);
  return true;
}
