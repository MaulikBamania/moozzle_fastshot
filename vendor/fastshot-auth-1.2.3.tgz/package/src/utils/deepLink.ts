import { Platform } from 'react-native';
import { AUTH_CONFIG } from '../constants';

/**
 * Get the default callback URL for OAuth
 * Returns platform-appropriate URL:
 * - Native (iOS/Android): fastshot-{project-id}://auth/callback
 * - Web: https://current-origin/auth/callback
 */
export function getDefaultCallbackUrl(): string {
  if (Platform.OS === 'web') {
    // Use HTTP URL for web browsers
    const origin = globalThis.location?.origin ?? '';
    return `${origin}/${AUTH_CONFIG.CALLBACK_PATH}`;
  }
  // Use deep link scheme for native
  return `${AUTH_CONFIG.DEEP_LINK_SCHEME}://${AUTH_CONFIG.CALLBACK_PATH}`;
}

/**
 * Parse OAuth callback URL and extract parameters
 */
export function parseCallbackUrl(url: string): {
  ticket?: string;
  error?: string;
  errorDescription?: string;
  clientState?: string;
} {
  try {
    // Handle both URL formats:
    // fastshot-{project-id}://auth/callback?ticket=xxx
    // fastshot-{project-id}://auth/callback?error=xxx&error_description=xxx

    // Extract query string
    const queryStart = url.indexOf('?');
    if (queryStart === -1) {
      return {};
    }

    // Get query string and strip any URL fragment (#)
    // iOS often appends a trailing # to callback URLs
    let queryString = url.substring(queryStart + 1);
    const hashIndex = queryString.indexOf('#');
    if (hashIndex !== -1) {
      queryString = queryString.substring(0, hashIndex);
    }

    const params = new URLSearchParams(queryString);

    return {
      ticket: params.get('ticket') || undefined,
      clientState: params.get('client_state') || undefined,
      error: params.get('error') || undefined,
      errorDescription: params.get('error_description') || undefined,
    };
  } catch {
    return {};
  }
}

/** Accept only this app's exact callback identity, including on native cold start. */
export function isAuthCallbackUrl(url: string): boolean {
  try {
    const parsed = new URL(url);
    const expected = new URL(getDefaultCallbackUrl());
    return !parsed.username && !parsed.password && parsed.protocol === expected.protocol &&
      parsed.host === expected.host && parsed.pathname === expected.pathname;
  } catch {
    return false;
  }
}

/**
 * Build the OAuth start URL
 */
export function buildOAuthStartUrl(
  provider: 'google' | 'apple',
  params: {
    tenant: string;
    returnTo: string;
    mode?: 'browser' | 'webview' | 'popup';
    clientChallenge: string;
    clientState: string;
    loginHint?: string;
  }
): string {
  const endpoint = provider === 'google' ? '/v1/auth/google/start' : '/v1/auth/apple/start';
  const url = new URL(endpoint, AUTH_CONFIG.AUTH_BROKER_URL);

  url.searchParams.set('tenant', params.tenant);
  url.searchParams.set('return_to', params.returnTo);
  url.searchParams.set('mode', params.mode || 'browser');
  url.searchParams.set('client_challenge', params.clientChallenge);
  url.searchParams.set('client_state', params.clientState);

  if (params.loginHint && provider === 'google') {
    url.searchParams.set('login_hint', params.loginHint);
  }

  return url.toString();
}
