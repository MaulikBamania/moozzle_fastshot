import { Platform } from 'react-native';

export const GALLERY_SIGN_IN_NOTICE = 'Sign-in is disabled in this published gallery preview.';

export function isGalleryPreview(): boolean {
  if (Platform.OS !== 'web' || typeof window === 'undefined') return false;
  const marked = (window as Window & { __FASTSHOT_GALLERY_PREVIEW__?: boolean }).__FASTSHOT_GALLERY_PREVIEW__;
  // Existing shared-CDN publications predate the explicit export marker.
  return marked === true || /^\/[0-9a-f]{8}-[0-9a-f-]{27}\/[0-9a-f]{16}(?:\/|$)/i.test(window.location.pathname);
}

export function requireInteractiveAuth(): void {
  if (isGalleryPreview()) throw new Error(GALLERY_SIGN_IN_NOTICE);
}
