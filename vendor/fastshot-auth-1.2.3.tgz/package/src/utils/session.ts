import type { SupabaseClient } from '@supabase/supabase-js';
import type { ExchangeTicketResponse } from '../types';
import { createAuthError } from './ticketExchange';

/**
 * Restore a Supabase session from exchange response
 *
 * IMPORTANT: We don't await setSession() because it can hang in some React Native
 * environments. Instead, we listen for onAuthStateChange and resolve when
 * SIGNED_IN fires.
 */
export function restoreSession(
  supabaseClient: SupabaseClient,
  exchangeResponse: ExchangeTicketResponse
): Promise<void> {
  return new Promise((resolve, reject) => {
    const TIMEOUT_MS = 15000;
    let settled = false;

    const cleanup = (subscription: { unsubscribe: () => void }, timeoutId: ReturnType<typeof setTimeout>) => {
      if (!settled) {
        settled = true;
        subscription.unsubscribe();
        clearTimeout(timeoutId);
      }
    };

    // Timeout handler
    const timeoutId = setTimeout(() => {
      if (!settled) {
        cleanup(subscription, timeoutId);
        reject(createAuthError('SESSION_RESTORE_FAILED', 'Session restore timed out after 15 seconds'));
      }
    }, TIMEOUT_MS);

    // Listen for auth state change FIRST
    const { data: { subscription } } = supabaseClient.auth.onAuthStateChange((event, session) => {
      if (settled) return;

      if (event === 'SIGNED_IN' && session) {
        cleanup(subscription, timeoutId);
        resolve();
      } else if (event === 'SIGNED_OUT') {
        cleanup(subscription, timeoutId);
        reject(createAuthError('SESSION_RESTORE_FAILED', 'Received SIGNED_OUT instead of SIGNED_IN'));
      }
    });

    // THEN fire setSession - don't await, just catch errors
    supabaseClient.auth.setSession({
      access_token: exchangeResponse.access_token,
      refresh_token: exchangeResponse.refresh_token,
    }).then(result => {
      if (result.error && !settled) {
        cleanup(subscription, timeoutId);
        reject(createAuthError('SESSION_RESTORE_FAILED', result.error.message));
      }
    }).catch(err => {
      if (!settled) {
        cleanup(subscription, timeoutId);
        reject(createAuthError(
          'SESSION_RESTORE_FAILED',
          err instanceof Error ? err.message : 'setSession failed'
        ));
      }
    });
  });
}
