import { getClientBinding, clearClientBinding } from './clientBinding';
import { AUTH_CONFIG, AUTH_ENDPOINTS, DEFAULT_AUTH_CONFIG } from '../constants';
import type { ExchangeTicketResponse, AuthError } from '../types';

/**
 * Validate that the exchange response contains all required fields
 */
function validateExchangeResponse(data: unknown): data is ExchangeTicketResponse {
  if (!data || typeof data !== 'object') return false;

  const response = data as Record<string, unknown>;

  return (
    typeof response.access_token === 'string' &&
    response.access_token.length > 0 &&
    typeof response.refresh_token === 'string' &&
    response.refresh_token.length > 0 &&
    typeof response.token_type === 'string' &&
    typeof response.expires_in === 'number' &&
    response.user !== null &&
    typeof response.user === 'object'
  );
}

/**
 * Check if an error is a timeout/abort error
 */
function isTimeoutError(error: unknown): boolean {
  if (error instanceof Error) {
    return error.name === 'AbortError' || error.message.includes('aborted');
  }
  return false;
}

/**
 * Check if an error is a network error
 */
function isNetworkError(error: unknown): boolean {
  if (error instanceof TypeError) {
    const message = error.message.toLowerCase();
    return (
      message.includes('fetch') ||
      message.includes('network') ||
      message.includes('failed to fetch') ||
      message.includes('networkerror')
    );
  }
  return false;
}

/**
 * Exchange a one-time ticket for Supabase session tokens
 */
export async function exchangeTicket(ticket: string, clientState?: string): Promise<ExchangeTicketResponse> {
  const url = `${AUTH_CONFIG.AUTH_BROKER_URL}${AUTH_ENDPOINTS.EXCHANGE_TICKET}`;

  // Create AbortController for timeout
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), DEFAULT_AUTH_CONFIG.TIMEOUT);

  try {
    const binding = await getClientBinding(clientState);
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ ticket, tenant: binding.tenant, return_to: binding.return_to, client_state: binding.client_state, code_verifier: binding.code_verifier }),
      signal: controller.signal,
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      const message = typeof errorData.detail === 'string' ? errorData.detail : errorData.detail?.message || errorData.message;

      if (response.status === 401) {
        throw createAuthError(
          'INVALID_TICKET',
          message || 'Invalid or expired ticket'
        );
      }

      throw createAuthError(
        'EXCHANGE_FAILED',
        message || `Ticket exchange failed: ${response.status}`
      );
    }

    const data: unknown = await response.json();

    // Validate response structure
    if (!validateExchangeResponse(data)) {
      // Log what we received for debugging
      console.error('[@fastshot/auth] Invalid exchange response shape');
      throw createAuthError(
        'EXCHANGE_FAILED',
        'Invalid response from auth server: missing required fields'
      );
    }

    await clearClientBinding(binding.client_state);
    return data;
  } catch (error) {
    if (isAuthError(error)) {
      throw error;
    }

    // Timeout error
    if (isTimeoutError(error)) {
      throw createAuthError(
        'NETWORK_ERROR',
        'Request timed out. Please check your connection and try again.',
        error
      );
    }

    // Network or other errors
    if (isNetworkError(error)) {
      throw createAuthError(
        'NETWORK_ERROR',
        'Network error during ticket exchange. Please check your connection.',
        error
      );
    }

    throw createAuthError(
      'EXCHANGE_FAILED',
      error instanceof Error ? error.message : 'Unknown error during ticket exchange',
      error
    );
  } finally {
    clearTimeout(timeoutId);
  }
}

/**
 * Create a typed auth error
 */
export function createAuthError(
  type: AuthError['type'],
  message: string,
  originalError?: unknown
): AuthError {
  return {
    type,
    message,
    originalError,
  };
}

/**
 * Type guard for AuthError
 */
export function isAuthError(error: unknown): error is AuthError {
  return (
    typeof error === 'object' &&
    error !== null &&
    'type' in error &&
    'message' in error
  );
}
